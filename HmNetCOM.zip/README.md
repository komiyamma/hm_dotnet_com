# hidemaru_dotnet_com
Hm.NetCOM 用 のリポジトリ。息が長くなりそうなのとソース自体が重要となるので別リポジトリとする。

https://秀丸マクロ.net/?page=nobu_tool_hm_dotnet_pinvoke